document.addEventListener('DOMContentLoaded', function () {
  const editBtn = document.querySelector('.edit-btn');
  const inputs = document.querySelectorAll('.info input');

  editBtn.addEventListener('click', function () {
    inputs.forEach(input => {
      input.disabled = !input.disabled;
    });

    if (editBtn.textContent === 'Edit') {
      editBtn.textContent = 'Save';
      editBtn.style.backgroundColor = '#4CAF50';
    } else {
      editBtn.textContent = 'Edit';
      editBtn.style.backgroundColor = 'hotpink';
      alert('Changes saved (not stored yet)');
    }
  });
});

function showSaveNotification() {
  const notif = document.getElementById("saveNotification");
  notif.classList.add("show");
  setTimeout(() => {
    notif.classList.remove("show");
  }, 3000);
}

// Attach to save button
document.addEventListener("DOMContentLoaded", () => {
  const saveBtn = document.querySelector("button[type='submit'], #saveBtn");
  if (saveBtn) {
    saveBtn.addEventListener("click", (e) => {
      e.preventDefault();
      showSaveNotification();
    });
  }
});
